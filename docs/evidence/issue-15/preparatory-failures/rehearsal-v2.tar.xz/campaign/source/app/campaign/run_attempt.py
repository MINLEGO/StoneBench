"""One fresh server attempt, executed by the existing lifecycle launcher."""
import asyncio
from contextlib import AsyncExitStack
from dataclasses import asdict
from importlib.metadata import version
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from app.campaign.plan import BUDGET, CALIBRATION_BUDGET, MODEL, PINS, PROVIDER, digest, load_secret, plan_hash, require_authorization
from app.harness.inspect_task import stonebench_task, encode
import app.harness.scripted
from inspect_ai import eval_async
from inspect_ai.event import ModelEvent
from inspect_ai.model import GenerateConfig, get_model, ModelOutput, ModelUsage, ChatCompletionChoice, ChatMessageAssistant
from inspect_ai.tool import ToolCall, ToolDef, mcp_server_http


def save(root, name, value):
    (root / name).write_text(encode(value), encoding="utf-8")


def provider_records(log):
    rows=[]
    for sample in log.samples or []:
        for event in sample.events:
            if not isinstance(event,ModelEvent):
                continue
            response=event.call.response if event.call and event.call.response else {}
            usage=response.get("usage") or {}
            rows.append({"response_id":response.get("id"),"routing_metadata":response.get("openrouter_metadata"),
                "raw_provider_usage":usage or None,"provider_reported_cost":usage.get("cost"),
                "inspect_usage_cost_is_not_route_exact":True})
    return rows


async def call(tools, name, **args):
    from app.harness.inspect_task import payload
    value = payload(await tools[name](**args))
    if value.get("status") != "ok":
        raise RuntimeError(f"{name} failed: {encode(value)}")
    return value


def assert_clean(snapshot, listing, description):
    state = snapshot["checkpoint_state"]
    if state["world_time"] != 0 or state["time_of_day"] != 0:
        raise RuntimeError("Fresh world clocks are not zero")
    if snapshot["input"] is not None or listing["checkpoints"]:
        raise RuntimeError("Fresh attempt retained input/checkpoints")
    raw = state["state"]
    if any(raw[name] for name in ("block_ticks", "fluid_ticks", "block_events")):
        raise RuntimeError("Fresh attempt retained pending queues/events")
    if any(block["block"] != "minecraft:air" or block.get("inventory") for block in raw["blocks"].values()):
        raise RuntimeError("Fresh observed zone has nonair/inventory state")
    if description["simulation_ticks"] != 0 or description["preparation_ticks"] != 0 or not description["frozen"]:
        raise RuntimeError("Preparation advanced world or failed to freeze")
    for name, expected in PINS.items():
        if name in description["environment"] and description["environment"][name] != expected:
            raise RuntimeError(f"Environment drift: {name}")


class Rehearsal:
    """Incomplete stone/chest checkpoint exercises retention; it is not a solver."""
    def __init__(self, attempt, budget, mode):
        self.attempt, self.budget, self.mode = attempt, budget, mode
        self.index = 0
        self.context_bytes = []

    def __call__(self, messages, tools, config):
        self.context_bytes.append(len(encode({"messages": [item.model_dump(mode="json") for item in messages],
            "tools": [ToolDef(tool).parameters.model_dump(mode="json") for tool in tools]}).encode()))
        rows = [("describe_task", {}), ("describe_rules", {}), ("describe_blocks", {})]
        sequence = [rows,
            [("modify_blocks", {"blocks": [{"x":1024,"y":79,"z":1024,"block":"minecraft:stone"},
                {"x":1025,"y":79,"z":1024,"block":"minecraft:chest", "parameters":{"facing":"north"},
                 "inventory":[{"slot":0,"item":"minecraft:diamond","count":7}]}], "notify_neighbors":True})],
            [("advance", {"ticks":3,"trace":True})],
            [("transition", {"max_ticks":20,"trace":True})],
            [("create_checkpoint", {})], [("list_checkpoints", {})]]
        if self.index < len(sequence):
            calls = sequence[self.index]
        elif self.index == len(sequence) and self.mode != "no_submission":
            checkpoint = next(json.loads(file.read_text(encoding="utf-8"))["checkpoint"]["checkpoint_id"]
                for file in self.attempt.root.glob("tool-*.json") if '"checkpoint":' in file.read_text(encoding="utf-8"))
            calls = [("submit_checkpoint", {"checkpoint_id":checkpoint})]
        else:
            calls = []
        self.index += 1
        # Controlled usage triggers real finalization after checkpoint publication.
        usage = ModelUsage(input_tokens=200, output_tokens=100, total_tokens=300, reasoning_tokens=90)
        if self.index == 5:
            usage = ModelUsage(input_tokens=self.budget.total - 100000, output_tokens=100,
                               total_tokens=self.budget.total - 99900, reasoning_tokens=90)
        return ModelOutput(model="stonebench-scripted/campaign-rehearsal", usage=usage,
            choices=[ChatCompletionChoice(message=ChatMessageAssistant(content="Scripted rehearsal", tool_calls=
                [ToolCall(id=f"{self.index}-{i}",function=name,arguments=args) for i,(name,args) in enumerate(calls)] or None),
                stop_reason="tool_calls" if calls else "stop")])


async def run():
    task_id, mode = os.environ["STONEBENCH_CAMPAIGN_TASK"], os.environ["STONEBENCH_CAMPAIGN_MODE"]
    if mode not in {"rehearsal", "calibration", "paid"}:
        raise ValueError("Unknown campaign mode")
    if mode != "rehearsal":
        require_authorization(os.environ["STONEBENCH_CAMPAIGN_AUTHORIZATION"],mode)
    root = Path(os.environ["STONEBENCH_CAMPAIGN_ATTEMPT"])
    root.mkdir(parents=True, exist_ok=False)
    budget = CALIBRATION_BUDGET if mode == "calibration" else BUDGET
    status = {"task_id": task_id, "mode": mode, "status": "infrastructure_error", "plan_sha256": plan_hash()}
    try:
        for package in ("inspect_ai", "mcp", "openai"):
            if version(package) != PINS[package]:
                raise RuntimeError(f"Version drift: {package}")
        server_root = Path(os.environ["STONEBENCH_SERVER_ROOTS"].split(";")[0])
        status["server_root"] = str(server_root)
        url = f"http://127.0.0.1:{os.environ['STONEBENCH_MCP_PORTS'].split(',')[0]}/mcp"
        async with mcp_server_http(url=url, timeout=2450) as connection:
            discovered = await connection.tools()
            tools = {ToolDef(item).name: item for item in discovered}
            if any(name.startswith("__test") for name in tools):
                raise RuntimeError("Campaign requires production tool catalogue")
            start = await call(tools, "start_attempt", task_id=task_id, budget_tokens=budget.total)
            description = await call(tools, "describe_task")
            snapshot = await call(tools, "verification_snapshot")
            listing = await call(tools, "list_checkpoints")
            assert_clean(snapshot, listing, description)
            catalogue = [{"name":ToolDef(item).name,"description":ToolDef(item).description,
                          "parameters":ToolDef(item).parameters.model_dump(mode="json")} for item in discovered]
            save(root,"initial.json", {"start":start,"description":description,"snapshot":snapshot,"checkpoints":listing,
                "catalogue":catalogue,"catalogue_sha256":digest(encode(catalogue).encode()),"reset_checked":True})
        config = GenerateConfig(temperature=0, parallel_tool_calls=False, max_retries=0, cache_prompt=False,
            extra_headers={"X-OpenRouter-Metadata":"enabled"})
        task, attempt = stonebench_task(url, budget, root / "harness", task_id=task_id, config=config, initialize=False,
            max_context_bytes=524288,stop_on_missing_usage=True)
        if mode == "calibration":
            # At most two provider calls in a read-only phase with the actual schema/context.
            attempt.ledger.finalize("provider_calibration_read_only")
        if mode == "rehearsal":
            script = Rehearsal(attempt,budget,"no_submission" if task_id == "5x5-speed" else "selected")
            model = get_model("stonebench-scripted/campaign-rehearsal",script=script)
        else:
            # Only inherited environment auth; no secret in model args/logs/archive.
            load_secret()
            model = get_model(MODEL,provider=PROVIDER,max_retries=0)
        logs = await eval_async(task, model=model, log_dir=str(root / "inspect-logs"), log_format="json",
            log_model_api=True, ctl_server=False, max_samples=1,max_tasks=1,retry_on_error=0)
        log = logs[0]
        status.update(status=log.status, result=attempt.report, selected_checkpoint_id=attempt.selected,
            total_tokens=attempt.ledger.total_tokens, known_tokens_subtotal=attempt.ledger.known_tokens,
            calls=attempt.ledger.calls, error=log.error.model_dump(mode="json") if log.error else None)
        status["provider_records"] = provider_records(log)
        if mode == "rehearsal":
            if log.status != "success" or (task_id == "5x5-speed" and attempt.report["status"] != "no_submission"):
                raise RuntimeError("Rehearsal native Inspect result failed")
            status["offline_context_bytes"] = script.context_bytes
            status["offline_context_is_not_provider_usage"] = True
            # Leave explicit residue so next task's fresh startup proves isolation.
            async with mcp_server_http(url=url, timeout=2450) as connection:
                tools = {ToolDef(item).name:item for item in await connection.tools()}
                residue = await call(tools,"verification_snapshot")
                if residue["checkpoint_state"]["world_time"] <= 0:
                    raise RuntimeError("Isolation control did not leave nonzero clocks")
                save(root,"residue.json",residue)
        save(root,"status.json",status)
        if log.status != "success":
            raise RuntimeError("Inspect attempt failed; retained status has diagnostics")
    except BaseException as exc:
        status["failure_type"] = type(exc).__name__
        # Provider exception bodies can echo request context; do not persist arbitrary repr.
        save(root,"status.json",status)
        raise


if __name__ == "__main__":
    asyncio.run(run())
