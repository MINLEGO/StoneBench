# Verdict du prototype des entrées

Succès : **True** ; 72 exécutions, 12 comparaisons de modes.

Décalage reproduit : True. Répétabilité : True. États entre modes identiques : True.

| Exécution | Délai activation | Délai désactivation | Adaptateur activation | Fin du cycle |
| --- | ---: | ---: | ---: | ---: |
| torch-lever-direct-1 | 1 | 1 | 0 | 5 |
| torch-lever-direct-2 | 1 | 1 | 0 | 5 |
| torch-lever-direct-3 | 1 | 1 | 0 | 5 |
| torch-lever-repeater-1 | 2 | 2 | 1 | 9 |
| torch-lever-repeater-2 | 2 | 2 | 1 | 9 |
| torch-lever-repeater-3 | 2 | 2 | 1 | 9 |
| torch-stone-button-direct-1 | 1 | 2 | 0 | 22 |
| torch-stone-button-direct-2 | 1 | 2 | 0 | 22 |
| torch-stone-button-direct-3 | 1 | 2 | 0 | 22 |
| torch-stone-button-repeater-1 | 2 | 2 | 1 | 24 |
| torch-stone-button-repeater-2 | 2 | 2 | 1 | 24 |
| torch-stone-button-repeater-3 | 2 | 2 | 1 | 24 |
| torch-wood-button-direct-1 | 1 | 2 | 0 | 32 |
| torch-wood-button-direct-2 | 1 | 2 | 0 | 32 |
| torch-wood-button-direct-3 | 1 | 2 | 0 | 32 |
| torch-wood-button-repeater-1 | 2 | 2 | 1 | 34 |
| torch-wood-button-repeater-2 | 2 | 2 | 1 | 34 |
| torch-wood-button-repeater-3 | 2 | 2 | 1 | 34 |
| repeater-1-lever-direct-1 | 1 | 1 | 0 | 5 |
| repeater-1-lever-direct-2 | 1 | 1 | 0 | 5 |
| repeater-1-lever-direct-3 | 1 | 1 | 0 | 5 |
| repeater-1-lever-repeater-1 | 2 | 2 | 1 | 9 |
| repeater-1-lever-repeater-2 | 2 | 2 | 1 | 9 |
| repeater-1-lever-repeater-3 | 2 | 2 | 1 | 9 |
| repeater-1-stone-button-direct-1 | 1 | 2 | 0 | 22 |
| repeater-1-stone-button-direct-2 | 1 | 2 | 0 | 22 |
| repeater-1-stone-button-direct-3 | 1 | 2 | 0 | 22 |
| repeater-1-stone-button-repeater-1 | 2 | 2 | 1 | 24 |
| repeater-1-stone-button-repeater-2 | 2 | 2 | 1 | 24 |
| repeater-1-stone-button-repeater-3 | 2 | 2 | 1 | 24 |
| repeater-1-wood-button-direct-1 | 1 | 2 | 0 | 32 |
| repeater-1-wood-button-direct-2 | 1 | 2 | 0 | 32 |
| repeater-1-wood-button-direct-3 | 1 | 2 | 0 | 32 |
| repeater-1-wood-button-repeater-1 | 2 | 2 | 1 | 34 |
| repeater-1-wood-button-repeater-2 | 2 | 2 | 1 | 34 |
| repeater-1-wood-button-repeater-3 | 2 | 2 | 1 | 34 |
| repeater-4-lever-direct-1 | 7 | 7 | 0 | 17 |
| repeater-4-lever-direct-2 | 7 | 7 | 0 | 17 |
| repeater-4-lever-direct-3 | 7 | 7 | 0 | 17 |
| repeater-4-lever-repeater-1 | 8 | 8 | 1 | 21 |
| repeater-4-lever-repeater-2 | 8 | 8 | 1 | 21 |
| repeater-4-lever-repeater-3 | 8 | 8 | 1 | 21 |
| repeater-4-stone-button-direct-1 | 7 | 8 | 0 | 28 |
| repeater-4-stone-button-direct-2 | 7 | 8 | 0 | 28 |
| repeater-4-stone-button-direct-3 | 7 | 8 | 0 | 28 |
| repeater-4-stone-button-repeater-1 | 8 | 8 | 1 | 30 |
| repeater-4-stone-button-repeater-2 | 8 | 8 | 1 | 30 |
| repeater-4-stone-button-repeater-3 | 8 | 8 | 1 | 30 |
| repeater-4-wood-button-direct-1 | 7 | 8 | 0 | 38 |
| repeater-4-wood-button-direct-2 | 7 | 8 | 0 | 38 |
| repeater-4-wood-button-direct-3 | 7 | 8 | 0 | 38 |
| repeater-4-wood-button-repeater-1 | 8 | 8 | 1 | 40 |
| repeater-4-wood-button-repeater-2 | 8 | 8 | 1 | 40 |
| repeater-4-wood-button-repeater-3 | 8 | 8 | 1 | 40 |
| piston-lever-direct-1 | 1 | 1 | 0 | 9 |
| piston-lever-direct-2 | 1 | 1 | 0 | 9 |
| piston-lever-direct-3 | 1 | 1 | 0 | 9 |
| piston-lever-repeater-1 | 2 | 2 | 1 | 13 |
| piston-lever-repeater-2 | 2 | 2 | 1 | 13 |
| piston-lever-repeater-3 | 2 | 2 | 1 | 13 |
| piston-stone-button-direct-1 | 1 | 2 | 0 | 24 |
| piston-stone-button-direct-2 | 1 | 2 | 0 | 24 |
| piston-stone-button-direct-3 | 1 | 2 | 0 | 24 |
| piston-stone-button-repeater-1 | 2 | 2 | 1 | 26 |
| piston-stone-button-repeater-2 | 2 | 2 | 1 | 26 |
| piston-stone-button-repeater-3 | 2 | 2 | 1 | 26 |
| piston-wood-button-direct-1 | 1 | 2 | 0 | 34 |
| piston-wood-button-direct-2 | 1 | 2 | 0 | 34 |
| piston-wood-button-direct-3 | 1 | 2 | 0 | 34 |
| piston-wood-button-repeater-1 | 2 | 2 | 1 | 36 |
| piston-wood-button-repeater-2 | 2 | 2 | 1 | 36 |
| piston-wood-button-repeater-3 | 2 | 2 | 1 | 36 |

